#!/sbin/sh

echo -n '' > /tmp/fallback.log
exec >> /tmp/fallback.log 2>&1

echo "Mounting partitions"
echo "  * Mounting /system"
busybox grep -q '/system ' /proc/mounts || busybox mount /system
echo "  * Mounting /data"
busybox grep -q '/data ' /proc/mounts || busybox mount /data
echo ""

ACTION=$1

if busybox test "$ACTION" = "install" && busybox test ! -f /system/etc/mounts2sd.sh; then
    echo "Removing old sd-ext script"
    echo "  * Running a2sd_cleanup"
    busybox chmod 0775 /data/local/a2sd_cleanup
    /data/local/a2sd_cleanup
    echo "  * Removing a2sd_cleanup"
    busybox rm -rf /data/local/a2sd_cleanup
    echo ""

else
    busybox rm -rf /data/local/a2sd_cleanup
fi

if busybox test "$ACTION" = "install"; then
    echo "Installing Mounts2SD"
    if busybox test ! -d /system/etc/init.d; then
        echo "  * Creating missing directory /system/etc/init.d"
        busybox mkdir /system/etc/init.d
    fi
    echo "  * Installing mounts2sd.sh into /system/etc/"
    busybox mv /data/local/mounts2sd.sh /system/etc/ || exit 1
    busybox chmod 0775 /system/etc/mounts2sd.sh || exit 1
    busybox chown 0.0 /system/etc/mounts2sd.sh || exit 1
    echo "  * Installing 10mounts2sd-runner into /system/etc/init.d/"
    busybox mv /data/local/10mounts2sd-runner /system/etc/init.d/ || exit 1
    busybox chmod 0775 /system/etc/init.d/10mounts2sd-runner || exit 1
    busybox chown 0.0 /system/etc/init.d/10mounts2sd-runner || exit 1
    echo ""

    echo "Processing system applications"
    directories="/data/app-system"

    for path in /system/*; do
        folder=$(busybox basename $path)_s

        if busybox test -d /data/$folder; then
            directories="$directories /data/$folder"
        fi
    done

    for dataLocation in $directories; do
        echo "  * Checking $dataLocation"

        systemLocation="$(echo "$dataLocation" | busybox sed 's/\/data\/\(.*\)\(_s\|-system\)/\/system\/\1/')"

        for file in $dataLocation/*; do
            if busybox test -f $file && busybox test ! -e $systemLocation/$(busybxo basename $file); then
                echo "  - Linking $file to $systemLocation/"
                busybox ln -s $file $systemLocation/
            fi
        done
    done

    echo ""

else
    echo "Uninstalling Mounts2SD"
    if busybox test -f /system/etc/mounts2sd.sh; then
        echo "  * Removing /system/etc/mounts2sd.sh"
        busybox rm -rf /system/etc/mounts2sd.sh || exit 1

    else
        echo "  * Cannot find /system/etc/mounts2sd.sh!"
    fi

    if busybox test -f /system/etc/init.d/10mounts2sd-runner; then
        echo "  * Removing /system/etc/init.d/10mounts2sd-runner"
        busybox rm -rf /system/etc/init.d/10mounts2sd-runner || exit 1

    else
        echo "  * Cannot find /system/etc/init.d/10mounts2sd-runner!"
    fi
    echo ""
fi

exit 0

