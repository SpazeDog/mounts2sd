#!/sbin/sh

echo -n '' > /tmp/fallback.log
exec >> /tmp/fallback.log 2>&1

echo "Mounting partitions"
echo "  * Mounting /system"
busybox grep -q '/system ' /proc/mounts || busybox mount /system
echo "  * Mounting /data"
busybox grep -q '/data ' /proc/mounts || busybox mount /data
echo ""

echo "Installing SQLite3 binary"
echo "  * Installing sqlite3 into /system/xbin/sqlite3"
busybox mv /data/local/sqlite3 /system/xbin/ || exit 1
busybox chmod 0755 /system/xbin/sqlite3 || exit 1
busybox chown 0.2000 /system/xbin/sqlite3 || exit 1
echo ""

exit 0

